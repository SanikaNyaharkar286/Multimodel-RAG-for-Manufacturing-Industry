"""scripts package."""
